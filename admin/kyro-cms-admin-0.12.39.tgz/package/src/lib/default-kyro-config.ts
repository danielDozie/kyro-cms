export default {
  collections: [],
  globals: [],
};
